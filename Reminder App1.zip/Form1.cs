﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace $safeprojectname$
{
    public partial class Form1 : Form
    {
        SqlConnection sqlCon = new SqlConnection(@"Data Source=.\SQLEXPRESS;AttachDbFilename=C:\Users\SONY\Documents\DB\ReminderDB.mdf;Integrated Security=True;Connect Timeout=30;User Instance=True");
        int ReminderId = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                if (sqlCon.State == ConnectionState.Closed)
                    sqlCon.Open();
                if (btnSave.Text == "Save")
                {
                    SqlCommand sqlCmd = new SqlCommand("ReminderAddOrEdit", sqlCon);
                    sqlCmd.CommandType = CommandType.StoredProcedure;
                    sqlCmd.Parameters.AddWithValue("@mode", "Add");
                    sqlCmd.Parameters.AddWithValue("@ReminderId", 0);
                    sqlCmd.Parameters.AddWithValue("@Date", txtDate.Text.Trim());
                    sqlCmd.Parameters.AddWithValue("@Time", txtTime.Text.Trim());
                    sqlCmd.Parameters.AddWithValue("@ReminderText", txtReminder.Text.Trim());
                    sqlCmd.ExecuteNonQuery();
                    MessageBox.Show("Saved Successfully");
                }
                else
                {
                    SqlCommand sqlCmd = new SqlCommand("ReminderAddOrEdit", sqlCon);
                    sqlCmd.CommandType = CommandType.StoredProcedure;
                    sqlCmd.Parameters.AddWithValue("@mode", "Edit");
                    sqlCmd.Parameters.AddWithValue("@ReminderId",ReminderId);
                    sqlCmd.Parameters.AddWithValue("@Date", txtDate.Text.Trim());
                    sqlCmd.Parameters.AddWithValue("@Time", txtTime.Text.Trim());
                    sqlCmd.Parameters.AddWithValue("@ReminderText", txtReminder.Text.Trim());
                    sqlCmd.ExecuteNonQuery();
                    MessageBox.Show("Updated Successfully");
                }
                Reset();
                FillDataGridView();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error Message");
            } 
            finally
            {
                sqlCon.Close();
            }
        }
        void FillDataGridView()
        {
            if (sqlCon.State == ConnectionState.Closed)
                sqlCon.Open();
            SqlDataAdapter sqlDa = new SqlDataAdapter("ReminderViewOrSearch", sqlCon);
            sqlDa.SelectCommand.CommandType = CommandType.StoredProcedure;
            sqlDa.SelectCommand.Parameters.AddWithValue("@ReminderDate", txtSearch.Text.Trim());
            DataTable dtbl = new DataTable();
            sqlDa.Fill(dtbl);
            dgvReminder.DataSource = dtbl;
            dgvReminder.Columns[0].Visible = false;
            sqlCon.Close();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                FillDataGridView();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message, "Error Message");
            }
        }

        private void dgvReminder_DoubleClick(object sender, EventArgs e)
        {
            if (dgvReminder.CurrentRow.Index != -1)
            {
                ReminderId = Convert.ToInt32(dgvReminder.CurrentRow.Cells[0].Value.ToString());
                txtDate.Text = dgvReminder.CurrentRow.Cells[1].Value.ToString();
                txtTime.Text = dgvReminder.CurrentRow.Cells[2].Value.ToString();
                txtReminder.Text = dgvReminder.CurrentRow.Cells[3].Value.ToString();
                btnSave.Text = "Update";
                btnDelete.Enabled = true;
            }
        }
        void Reset()
        {
            txtDate.Text = txtTime.Text = txtReminder.Text = "";
            btnSave.Text = "Save";
            ReminderId = 0;
            btnDelete.Enabled = false;
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            Reset();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            //Reset();
            //FllDataGridView();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                if (sqlCon.State == ConnectionState.Closed)
                    sqlCon.Open();
                    SqlCommand sqlCmd = new SqlCommand("ReminderDeletion", sqlCon);
                    sqlCmd.CommandType = CommandType.StoredProcedure;
                    sqlCmd.Parameters.AddWithValue("@ReminderId", ReminderId);
                    sqlCmd.ExecuteNonQuery();
                    MessageBox.Show("Deleted Successfully");
                    Reset();
                    FillDataGridView();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message, "Error Message");
            }
        }

        
    }
}
